<?php
require 'config/conex.php';
$c = $_POST["c"];
$v = $_POST["v"];
$t = $c*$v;
$sql =" INSERT INTO ventas5(cantidad, valor, total) VALUES (".$c.",".$v.",".$t.")";

if($dbh->query($sql))
{
    echo "compra exitosa  ";
}else
{
    echo "fallo en la compra";
}
echo $t;

?>